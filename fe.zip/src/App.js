import DetailPage from "./Pages/EnterDetail.jsx";
function App() {
  return (
    <div>
      <DetailPage />
    </div>
  );
}

export default App;
