import { Box, Button, Container, TextField, Typography, FormControl, Card, CardContent } from "@mui/material"
import React from "react"
import axios from "axios"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const DetailPage = (props) => {
    const notify = (value) => {
        toast(value?.toString())
    }
    const [forCandidate, setForCandidate] = React.useState(false)
    const [candidates, setCandidates] = React.useState([])
    const [results, setResults] = React.useState()
    const [value, setValue] = React.useState()
    React.useEffect(() => {
        notify("Welcome!")
        axios.get(`http://localhost:4000/get-all?type=candidates`).then((res) => {
            setCandidates(res.data.data)
        })
        axios.get(`http://localhost:4000/get-all?type=votes`).then((res) => {
            setResults(res.data.data)
        })

    }, [])
    console.log(results, "Results")
    const getData = () => {
        axios.get(`http://localhost:4000/get-all?type=candidates`).then((res) => {
            setCandidates(res.data.data)
        })
    }
    const handler = (e) => {
        let obj = { ...value }
        console.log(value)
        obj[`${e?.target?.name}`] = e?.target?.value
        setValue(obj)
    }
    const Save = async () => {
        try {
            const response = await axios.post('http://localhost:4000/create-candidate', { ...value })
            if (response?.status === 200) {
                notify("Candidate Created SuccessFully")

                getData()
            }
        } catch (error) {
            notify(error?.message)

        }

    }

    const ForVote = async (id) => {
        try {
            const response = await axios.post('http://localhost:4000/vote', { ...value, voted_for: id })
            if (response?.status === 200) {
                notify(response?.data?.message)

            }
        } catch (error) {
            console.log(error)
            notify(error?.response?.data?.message)

        }

    }

    return (
        <Container>
            <ToastContainer />
            <Box sx={{ marginLeft: "50%", transform: "translateX(-50%)", border: "2px solid black", borderRadius: "5px", mt: 5, minWidth: 500, maxWidth: "fit-content", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", alignContent: "center" }}>
                <h1>Voting System</h1>
                <FormControl>
                    <Typography>Enter Your Name:</Typography>
                    <TextField name="name" onChange={(e) => handler(e)} />
                </FormControl><br />
                <FormControl>
                    <Typography>Enter Your Cnic:</Typography>
                    <TextField name="cnic" onChange={(e) => handler(e)} />
                </FormControl><br />
                {forCandidate ?
                    <FormControl>
                        <Typography>Enter Your Title:</Typography>
                        <TextField name="title" onChange={(e) => handler(e)} />
                    </FormControl>
                    : null}<br />
                <Box>
                    {candidates?.length ?
                        candidates?.map((candidate, index) => {
                            return (
                                <Card sx={{ m: 2 }} key={index}>
                                    <CardContent>
                                        <h3>{candidate?.title}</h3>
                                        <p>Name: {candidate?.name}</p>
                                        <p>CNIC: {candidate?.cnic}</p>
                                        <Button variant="contained" onClick={(e) => ForVote(candidate?._id)}>Vote!</Button>
                                    </CardContent>
                                </Card>
                            )
                        })
                        : null}
                </Box><br />
                <Box>{forCandidate ?
                    <Button onClick={Save} variant="contained">Save</Button>
                    : null}
                </Box><br /><br />
            </Box>
        </Container>
    )
}
export default DetailPage